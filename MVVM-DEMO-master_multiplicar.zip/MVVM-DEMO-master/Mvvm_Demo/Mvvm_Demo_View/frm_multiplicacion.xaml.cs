﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Mvvm_Demo_ViewModel;

namespace Mvvm_Demo_View
{
    /// <summary>
    /// Interaction logic for frm_multiplicacion.xaml
    /// </summary>
    public partial class frm_multiplicacion : Window
    {
        public frm_multiplicacion()
        {
            InitializeComponent();
        }
        

        private void btn_cargar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Convert.ToInt32(cb_num1.Text) > Convert.ToInt32(cb_num2.Text))
                {
                    MessageBox.Show("   Item_1 No Puede Ser Mayor a Item_2...!   ");
                }
            }
            catch 
            {

                MessageBox.Show("   Ingrese Los Datos a Operar...!   ");
            }

        }
    }
}
