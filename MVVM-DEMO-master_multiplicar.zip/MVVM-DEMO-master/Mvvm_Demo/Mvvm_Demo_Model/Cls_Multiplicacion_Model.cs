﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mvvm_Demo_Model
{
    public class Cls_Multiplicacion_Model
    {
        String _s_multi, _s_num1, _s_num2, _s_msj;

        public string S_msj
        {
            get
            {
                return _s_msj;
            }

            set
            {
                _s_msj = value;
            }
        }

        public String S_multi
        {
            get
            {
                return _s_multi;
            }

            set
            {
                _s_multi = value;
            }
        }

        public String S_num1
        {
            get
            {
                return _s_num1;
            }

            set
            {
                _s_num1 = value;
            }
        }

        public String S_num2
        {
            get
            {
                return _s_num2;
            }

            set
            {
                _s_num2 = value;
            }
        }
    }
}
