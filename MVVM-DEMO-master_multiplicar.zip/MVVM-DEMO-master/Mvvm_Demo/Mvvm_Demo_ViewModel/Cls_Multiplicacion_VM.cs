﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Mvvm_Demo_Model;

namespace Mvvm_Demo_ViewModel
{
    public class Cls_Multiplicacion_VM : ObervableObject
    {
        private Cls_Multiplicacion_Model mtModel;
        private readonly ObservableCollection<string> _history = new ObservableCollection<string>();

        public Cls_Multiplicacion_VM()
        {
            this.mtModel = new Cls_Multiplicacion_Model();
            S_num1 = "0";
            S_num2 = "0";
            S_multi = "0";

        }

        public String S_num1
        {
            get
            {
                return mtModel.S_num1;
            }

            set
            {
                mtModel.S_num1 = value;
                RaisePropertyChangedEvent("S_num1");
            }
        }

        public String S_num2
        {
            get
            {
                return mtModel.S_num2;
            }

            set
            {
                mtModel.S_num2 = value;
                RaisePropertyChangedEvent("S_num2");
            }
        }

        public String S_multi
        {
            get
            {
                return mtModel.S_multi;
            }

            set
            {
                mtModel.S_multi = value;
                RaisePropertyChangedEvent("S_multi");
            }
        }

        

        public IEnumerable<string> History
        {
            get { return _history; }
        }

        public ICommand CalcularMultiplicacionCommand
        {
            get { return new DelegateCommand(CalcularMultiplicacion); }
        }

        private void CalcularMultiplicacion()
        {
            try
            {
                RemoveToHistory();

                Int32 i_num1 = Convert.ToInt32(S_num1);
                Int32 i_num2 = Convert.ToInt32(S_num2);
                Int32 i_multi = Convert.ToInt32(S_multi);
                Int32 i_result;

                if (i_num1 <= i_num2)
                {
                    do
                    {
                        i_result = i_multi * i_num1;
                        AddToHistory(i_num1 + "X" + i_multi + "=" + i_result);

                        i_num1++;

                    } while (i_num1 <= i_num2);
                }
                else
                {
                    return;
                }
            }
            catch (Exception)
            {
                return ;
            }

        }

        private void AddToHistory(string item)
        {
            if (!_history.Contains(item))
                _history.Add(item);
        }

        private void RemoveToHistory()
        {
            _history.Clear();
        }

        public ICommand LimpiarDatosCommand
        {
            get { return new DelegateCommand(LimpiarDatos); }
        }

        private void LimpiarDatos()
        {
            S_multi = "";
            S_num1 = "";
            S_num2 = "";
            RemoveToHistory();
        }

    }
}
