# MVVM-DEMO
Pequeña demostración de una aplicación desarrollada con el patrón de diseño.
